#include <ros/ros.h>
#include <mrvk_driver/communication_interface.h>

#include <std_srvs/Trigger.h>
#include <geometry_msgs/Twist.h>
#include <std_msgs/Float32MultiArray.h>
#include <signal.h>
#include <mrvk_driver/HwInterface.h>
#include <controller_manager/controller_manager.h>
#include <mrvk_driver/callbacks.h>


//todo spravit nastavenie parametrov motora
//polohovanie kamery
//rozdelit komunikaciu na 3 porty

class MrvkDriver{

public:
	MrvkDriver() : mrvkHW(){

		if(mrvkHW.init(&hw, &robot_transmissions) != 2){
			ROS_ERROR("init nezbehol");
			ros::shutdown();
		}

		joint_to_act = robot_transmissions.get<transmission_interface::JointToActuatorVelocityInterface>();
		act_to_joint = robot_transmissions.get<transmission_interface::ActuatorToJointStateInterface>();
		this->velocity = mrvkHW.getVelVector();
		this->velocity_command = mrvkHW.getVelCmdVector();

		std::vector<mrvk::Limits> limits = mrvkHW.getLimits();
		for(int i=0; i< limits.size(); i++){
			ROS_ERROR("%s",limits[i].joint.c_str());
			jnt_limit_interface.registerHandle(joint_limits_interface::VelocityJointSaturationHandle(hw.get<hardware_interface::VelocityJointInterface>()->getHandle(limits[i].joint),limits[i].joint_info));
		}
		std::vector<std::string> ports;
		int baud;
		int stopBits;
		int byteSize;
		int parity;

		ros::NodeHandle n("~");

		//n.param("port_names",ports);	//todo nenatahuje to porty so z param
		n.getParam("port_names",ports);
		n.param<int>("baudrate", baud, 230400);
		n.param<int>("stop_bits", stopBits, 1);
		n.param<int>("parity", parity, 1);
		n.param<int>("byte_size", byteSize, 8);
		n.param<int>("publish_rate", publish_rate, 10);

		comunication_interface = new CommunicationInterface(ports, baud, stopBits, parity, byteSize);
		callbacks = new MrvkCallbacks(comunication_interface);

		//TODO toto prec Miso: zatial to tu chcem nechat potom by som spravil diagnostic updater
		pub_MCBlStatus = n.advertise<mrvk_driver::Mcb_status>("motor_status_left", 10); //publishery s konkretnou statusovou spravou
		pub_MCBrStatus = n.advertise<mrvk_driver::Mcb_status>("motor_status_right", 10); //publishery s konkretnou statusovou spravou
		pub_MBStatus = n.advertise<mrvk_driver::Mb_status>("main_board_status", 10);

	}

	bool init(){

		ROS_ERROR("robot init"); //TODO prerobit na info alebo prec

		if (!comunication_interface->init())
			return false;

		SET_MAIN_BOARD config;

		//TODO funkciu setMbFromParam presunut do comunication interface a prerobit set mainboart aby si to pitala sama
		callbacks->setMbFromParam(&config);							//nastavi default parametre
		comunication_interface->setMainBoard(&config);

		/*REGULATOR_MOTOR regulator;
		bool regulation_type;
		callbacks->setMotorParametersFromParam(&regulator, &regulation_type);			//nastavi default parametre
		comunication_interface->setMotorParameters(regulator, regulation_type);*/

		//TODO centralstop spojazdnit
		/*if (!comunication_interface->resetCentralStop())
			return false;*/

		 return true;

	}

	void read(){

		velocity->at(0) = comunication_interface->getSpeedLeftWheel();
		velocity->at(1) = comunication_interface->getSpeedRightWheel();

		/*
		 * TODO toto prec
		 *
		velocity->at(0) = velocity_command->at(0);
		velocity->at(1) = velocity_command->at(1);
		//ROS_ERROR("1 vel = %lf,vel = %lf, cmd = %lf, cmd = %lf",velocity->at(0),velocity->at(1),velocity_command->at(0),velocity_command->at(1));
		/*
		 * TODO toto prec
		 * */
		act_to_joint->propagate();

		pub_MCBlStatus.publish(comunication_interface->getStatusMCB(CommunicationInterface::LEFT_MOTOR_ADRESS));
		pub_MCBrStatus.publish(comunication_interface->getStatusMCB(CommunicationInterface::RIGHT_MOTOR_ADRESS));
		pub_MBStatus.publish(comunication_interface->getStatusMB());
	}

	void write(){
		jnt_limit_interface.enforceLimits(ros::Duration(0.1)); //TODO ros::duration prerobit
		joint_to_act->propagate();
		writeMB();
		writeMotors();
		comunication_interface->waitToRead();
	}

	//TODO takto stop nebude fungovat kontroller tam natlaci svoje veci - PREROBIT
	void stop(){

		ROS_ERROR("stop");
		comunication_interface->setSpeedLeftMotor(0);
		comunication_interface->setSpeedRightMotor(0);
		comunication_interface->setCameraPosition(0, 0);
	}

	int getFrequence(){

		return publish_rate;
	}

	double getPeriod(){

		return 1/publish_rate;
	}
	hardware_interface::RobotHW* getHw(){
		return &hw;
	}

private:

	int publish_rate;
	std::vector<double>* velocity;
	std::vector<double>* velocity_command;
	MrvkCallbacks *callbacks;


	CommunicationInterface *comunication_interface;

	ros::Publisher pub_MCBlStatus;
	ros::Publisher pub_MCBrStatus;
	ros::Publisher pub_MBStatus;

	hardware_interface::RobotHW hw;
	mrvk::HwInterface mrvkHW;
	transmission_interface::RobotTransmissions robot_transmissions;

	transmission_interface::JointToActuatorVelocityInterface* joint_to_act;
	transmission_interface::ActuatorToJointStateInterface* act_to_joint;
	joint_limits_interface::VelocityJointSaturationInterface jnt_limit_interface;

	void writeMB(){

		bool success = false;

		if (comunication_interface->getMainBoard()->getCommandID()==REQUEST_COMMAND_FLAG){
			comunication_interface->MBStatusUpdate();

		}else {
			success = comunication_interface->sendMainBoardStruct();
		}
	}

	void writeMotors(){

		bool success = false;
		static double speedL = 0;
		static double speedR = 0;

		if (speedL != velocity_command->at(0) || speedR != velocity_command->at(1)){
			comunication_interface->setSpeedLeftMotor(velocity_command->at(0));
			comunication_interface->setSpeedRightMotor(velocity_command->at(1));
		}
		else{
			comunication_interface->LeftMCBStatusUpdate();
			comunication_interface->RightMCBStatusUpdate();
		}
	}
};


int main (int argc, char **argv){

	ros::init(argc, argv, "mrvk_driver");
	ros::NodeHandle n("~");

	MrvkDriver driver;
	driver.init();

	controller_manager::ControllerManager cm(driver.getHw());

	ros::AsyncSpinner spinner(1);
	spinner.start();
	ros::Rate rate(driver.getFrequence());
	
	while (n.ok())
	{
		sleep(1);
		driver.read();
		cm.update(ros::Time::now(), ros::Duration(driver.getPeriod()));
		driver.write();
		rate.sleep();
	}
	
return 0;
}

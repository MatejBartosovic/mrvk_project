#ifndef COMMUNICATION_INTERFACE_H_
#define COMMUNICATION_INTERFACE_H_

#include <mrvk_driver/command.h>
#include <serial/serial.h>
#include <boost/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/make_shared.hpp>

#include <mrvk_driver/conversions.h>

class CommunicationInterface : public Conversions{
public:

	const static int MAIN_BOARD = 0;
	const static int LEFT_MOTOR = 1;
	const static int RIGHT_MOTOR = 2;


	CommunicationInterface(std::vector<std::string> ports, int baudrate, int stopBits, int parity, int byteSize);
	~CommunicationInterface();
	bool init();
	bool isActive();
	void registerMutex(pthread_mutex_t* mutex);
	bool getCallbackResult();
	int waitToRead();


	//MAIN BOARD
	//jednorazove prikazy
	bool MBStatusUpdate();
	bool setCameraVelocity(double linearX, double angularZ);
	bool setCameraPosition(double linearX, double angularZ);
	bool setMainBoard(SET_MAIN_BOARD *param);
	//prikazy, ktore  sa ulozia do struktury a na ich zapis je potrebne zavolat funkciu writeMB
	bool sendMainBoardStruct();
	MBCommand* getMainBoard();


	//MOTOR BOARD
	bool LeftMCBStatusUpdate();
	bool RightMCBStatusUpdate();
	bool setSpeedLeftMotor(double speed);
	bool setSpeedRightMotor(double speed);
	bool resetFlags();
	bool setMotorParameters(REGULATOR_MOTOR regulator, bool regulation_type);

	//bool resetCentralStop();

	void close();

private:
	void setupPort(int sb,int p,int bs);

	bool isAnswerOk();

	void notifyAllCallbacks(bool response);
	void processCallbacks();

	bool write(serial::Serial* device,uint8_t *dataWrite, int lengthWrite);
	bool read(int lengthRead);
	void setFds(fd_set *set,int* flag);
	int getReadableFd(fd_set *set,int* flag);

	bool active;
	std::vector<serial::Serial*> my_serials;
	MCBCommand lavy;
	MCBCommand pravy;
	MBCommand mb;


	//todo nestaci to ako lokalne premenne??
	std::vector<std::string> ports;
	int fd_max;
	std::vector<int> read_lengths;
	int baud;
	int byteSize;
	int stopBits;
	int parity;
	pthread_mutex_t callbacks_mutex;
	std::vector<pthread_mutex_t*> waitings_callbacks;
	std::vector<pthread_mutex_t*> processed_callbacks;
	bool callback_res;
};

#endif /* COMMUNICATION_INTERFACE_H_ */

